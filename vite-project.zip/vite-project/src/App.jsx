import React from "react";
import "./App.css"; 
import Hero from "Hero.jsx"; 
import Navigation from "Navigation.jsx";  

const App = () => {

return (
    <>
        <Navigation />
        <Hero />
    </>
);
};
export default App;
