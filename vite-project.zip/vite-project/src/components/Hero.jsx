import React from "react";

const Hero = () => {
    // NOTE: Changed image paths from './images/' to '/images/'
    // to correctly reference assets in the public folder.
    return (  
        <main className="hero container">
            
            {/* 1. LEFT COLUMN: All text, buttons, and shopping icons */}
            <div className="hero-left-content"> 
                
                <div className="hero-content">
                    <h1>YOUR FEET 
                        <br/>DESERVE 
                        <br/>THE BEST
                    </h1>
                    <p>YOUR FEET DESERVE THE BEST AND WE’RE HERE TO HELP YOU WITH OUR SHOES.
                        <br/>YOUR FEET DESERVE THE BEST AND WE’RE HERE TO HELP YOU WITH OUR SHOES.
                    </p>
                </div>
                
                <div className="hero-btn">
                    <button>Shop Now</button>
                    <button className="secondary-btn">Category</button>
                </div>
                <div className="Shopping">
                    <p>Also Available On</p>
                    <div className="flip-icons">
                        {/* Corrected JSX syntax for self-closing tags and path */}
                        <img src="/images/amazon.svg" alt="Amazon logo" />
                        <img src="/images/flipkart.png" alt="Flipkart logo" />
                    </div>
                </div>

            </div>
            
            {/* 2. RIGHT COLUMN: Shoe Image */}
            <div className="hero-image">
                {/* Corrected JSX syntax for self-closing tag and path */}
                <img src="/images/shoe_image.png" alt="Shoe"/>
            </div>
            
        </main>
    );
};

export default Hero;
